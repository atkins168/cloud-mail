#!/usr/bin/env node
/**
 * Cloud Mail 一键部署到 Cloudflare（Windows / macOS / Linux 通用）
 * 项目：https://github.com/maillab/cloud-mail
 *
 * 用法（在这个目录下）:
 *   node deploy-cloud-mail.mjs
 *   node deploy-cloud-mail.mjs --yes --domain mail.example.com --admin-email admin@mail.example.com
 *   node deploy-cloud-mail.mjs --worker-name my-mail --d1-name mydb --kv-name mykv --r2-name myr2
 *
 * 前置条件:
 *   1. Node.js 18+（node -v 确认）
 *   2. 已登录 wrangler：先跑一次 `npx wrangler login`（浏览器授权）
 *      或设置环境变量 CLOUDFLARE_API_TOKEN
 *   3. 国内网络连不上 Cloudflare 时：set HTTPS_PROXY=http://127.0.0.1:10808
 *   4. R2 需先在 Cloudflare Dashboard 里激活过（需要绑卡，免费 10GB/月）
 *
 * 脚本做的事（全部幂等，可反复跑）:
 *   1. 检查 node / pnpm / wrangler 登录状态
 *   2. 交互式收集：邮件域名、管理员邮箱（或用命令行参数）
 *   3. 自动创建（或复用）D1 / KV / R2
 *   4. 生成 jwt_secret，生成 mail-worker/wrangler.toml 并回填真实 ID
 *   5. pnpm install（mail-vue + mail-worker）并构建前端到 mail-worker/dist
 *   6. wrangler deploy
 *   7. 调用 https://<worker>/api/init/<jwt_secret> 初始化数据库
 *
 * 部署后还需手动做（脚本做不了）:
 *   A. 用管理员邮箱在网页上注册账号（自动成为管理员）
 *   B. 去 resend.com 申请 API Key，填到管理后台「设置」里（发邮件用）
 *   C. 域名 DNS 接入 Cloudflare 后，在 Email Routing 里把收件路由到本 Worker（收邮件用），
 *      并按 Resend 文档配好 SPF/DKIM/DMARC（发邮件用）
 */

import { execFileSync, spawnSync } from 'node:child_process';
import { createInterface } from 'node:readline';
import { randomBytes } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const ROOT = process.cwd();
const SRC = join(ROOT, 'cloud-mail');
const WORKER_DIR = join(SRC, 'mail-worker');
const VUE_DIR = join(SRC, 'mail-vue');
const IS_WIN = process.platform === 'win32';
const ARGS = process.argv.slice(2);
const AUTO_YES = ARGS.includes('--yes') || ARGS.includes('-y');

function argVal(name, def) {
  const i = ARGS.findIndex((a) => a === name);
  if (i >= 0 && ARGS[i + 1] && !ARGS[i + 1].startsWith('--')) return ARGS[i + 1];
  const eq = ARGS.find((a) => a.startsWith(name + '='));
  if (eq) return eq.slice(name.length + 1);
  return def;
}
const WORKER_NAME = argVal('--worker-name', 'cloud-mail');
const D1_NAME = argVal('--d1-name', 'cloud-mail-db');
const KV_TITLE = argVal('--kv-name', 'cloud-mail-kv');
const R2_BUCKET = argVal('--r2-name', 'cloud-mail-r2');

// ---------- 小工具 ----------

function log(msg = '') { console.log(msg); }
function step(n, msg) { console.log(`\n[步骤 ${n}] ${msg}`); }
function ok(msg) { console.log(`  ✓ ${msg}`); }
function warn(msg) { console.log(`  ! ${msg}`); }
function fail(msg) {
  console.error(`\n  ✗ 失败: ${msg}`);
  process.exit(1);
}

function run(cmd, args, opts = {}) {
  // Windows 上直接 spawn npx.cmd / pnpm.cmd 会报 EINVAL，走 cmd.exe /d /s /c 传裸命令名
  const { file, fargs } = IS_WIN ? winCmd(cmd, args) : { file: cmd, fargs: args };
  try {
    return execFileSync(file, fargs, {
      encoding: 'utf8', stdio: 'pipe',
      cwd: opts.cwd || ROOT,
      env: { ...process.env, ...(opts.env || {}) },
      maxBuffer: 64 * 1024 * 1024,
    });
  } catch (e) {
    const err = new Error(`命令失败: ${cmd} ${args.join(' ')}\n${(e.stdout || '')}${(e.stderr || e.message)}`);
    err.stdout = e.stdout; err.stderr = e.stderr;
    throw err;
  }
}

function runLive(cmd, args, opts = {}) {
  const { file, fargs } = IS_WIN ? winCmd(cmd, args) : { file: cmd, fargs: args };
  const r = spawnSync(file, fargs, {
    stdio: 'inherit', cwd: opts.cwd || ROOT, env: { ...process.env, ...(opts.env || {}) },
  });
  if (r.status !== 0) fail(`命令失败: ${cmd} ${args.join(' ')}（退出码 ${r.status}）`);
}

function winCmd(cmd, args) {
  const q = (a) => {
    const s = String(a);
    return /[\s"]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return { file: 'cmd.exe', fargs: ['/d', '/s', '/c', `${cmd} ${args.map(q).join(' ')}`] };
}

function extractWranglerError(msg) {
  const lines = String(msg).split('\n');
  const errs = lines.filter((l) => /\[ERROR\]/.test(l));
  if (errs.length) return errs.join('\n');
  return lines.filter((l) => l.trim()).slice(0, 6).join('\n');
}

const ID_RE = /(?:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|(?<![0-9a-f])[0-9a-f]{32}(?![0-9a-f]))/i;

function findUuidNear(output, name) {
  for (const line of String(output).split('\n')) {
    if (line.includes(name)) {
      const m = line.match(ID_RE);
      if (m) return m[0];
    }
  }
  return '';
}

async function ask(question, def = '') {
  if (AUTO_YES) return def;
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  const ans = await new Promise((r) => rl.question(`${question}${def ? `（默认 ${def}）` : ''}: `, r));
  rl.close();
  return ans.trim() || def;
}

async function confirm(msg) {
  if (AUTO_YES) return true;
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  const ans = await new Promise((r) => rl.question(`${msg} [Y/n] `, r));
  rl.close();
  return !/^n/i.test(ans.trim());
}

// ---------- 主流程 ----------

/** 拉取 URL 文本：先用 node fetch，失败则降级 curl（curl 认 HTTPS_PROXY 环境变量，Windows 自带 curl.exe） */
async function fetchText(url) {
  try {
    const res = await fetch(url);
    return await res.text();
  } catch (e1) {
    try {
      return run('curl', ['-sS', '--max-time', '60', url]);
    } catch {
      throw e1;
    }
  }
}

async function main() {
  log('=== Cloud Mail 一键部署到 Cloudflare ===');
  if (!existsSync(join(SRC, 'mail-worker', 'wrangler.toml'))) fail('找不到 cloud-mail 源码，请确认 cloud-mail/ 目录完整');

  // 步骤 1: 环境检查
  step(1, '检查 Node.js / pnpm');
  const major = parseInt(process.version.slice(1).split('.')[0], 10);
  if (major < 18) fail(`Node.js 版本过低: ${process.version}，需要 18+`);
  ok(`Node.js ${process.version}`);
  let hasPnpm = true;
  try { run('pnpm', ['--version']); ok(`pnpm ${run('pnpm', ['--version']).trim()}`); }
  catch { hasPnpm = false; }
  if (!hasPnpm) {
    warn('未检测到 pnpm，尝试安装…');
    try { run('npm', ['install', '-g', 'pnpm']); ok('pnpm 安装成功'); }
    catch { fail('pnpm 安装失败，请手动执行 `npm install -g pnpm` 后重跑'); }
  }

  // 步骤 2: wrangler 登录
  step(2, '检查 wrangler 登录状态');
  try {
    const who = run('npx', ['wrangler', 'whoami']);
    const m = who.match(/You are logged in as ([^\n]+)/);
    ok(`已登录: ${m ? m[1].trim() : '（见上）'}`);
  } catch {
    fail('wrangler 未登录。请先跑一次 `npx wrangler login`（浏览器授权），再重新运行本脚本。\n国内网络需要先 set HTTPS_PROXY=http://127.0.0.1:10808');
  }

  // 步骤 3: 收集配置
  step(3, '配置邮件域名与管理员');
  let domains = argVal('--domain', '');
  if (!domains) domains = await ask('邮件域名（多个用英文逗号分隔，如 mail.example.com,example.com）');
  domains = domains.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
  if (!domains.length) fail('至少需要一个邮件域名');
  let adminEmail = argVal('--admin-email', '');
  if (!adminEmail) adminEmail = await ask('管理员邮箱（必须属于上面域名之一）');
  adminEmail = adminEmail.trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(adminEmail)) fail(`管理员邮箱格式不正确: ${adminEmail}`);
  const adminDomain = adminEmail.split('@')[1];
  if (!domains.includes(adminDomain)) fail(`管理员邮箱的域名 ${adminDomain} 不在域名列表里`);
  log(`  域名: ${domains.join(', ')}`);
  log(`  管理员: ${adminEmail}`);
  log(`  Worker 名: ${WORKER_NAME}`);

  // 步骤 4: 创建 D1 / KV / R2（幂等）
  step(4, '创建 Cloudflare 资源（D1 / KV / R2，已存在则复用）');

  let d1Id = '';
  try {
    const list = run('npx', ['wrangler', 'd1', 'list']);
    d1Id = findUuidNear(list, D1_NAME);
  } catch (e) { warn(`d1 list 失败: ${extractWranglerError(e.message).split('\n')[0]}`); }
  if (d1Id) ok(`D1 已存在: ${D1_NAME} (${d1Id})`);
  else {
    try {
      const out = run('npx', ['wrangler', 'd1', 'create', D1_NAME]);
      // 兼容 TOML (database_id = "...") 和 JSON ("database_id": "...") 两种输出格式
      const m = out.match(/"?database_id"?\s*[:=]\s*"([^"]+)"/);
      d1Id = m ? m[1] : findUuidNear(out, D1_NAME);
      if (!d1Id) {
        // 创建其实成功了但没解析到？再 list 一次找回来（自愈）
        try { d1Id = findUuidNear(run('npx', ['wrangler', 'd1', 'list']), D1_NAME); } catch {}
      }
      if (!d1Id) fail(`D1 创建成功但拿不到 ID:\n${out}`);
      ok(`D1 已创建: ${D1_NAME} (${d1Id})`);
    } catch (e) { fail(`D1 创建失败:\n${extractWranglerError(e.message)}`); }
  }

  let kvId = '';
  try {
    const list = run('npx', ['wrangler', 'kv', 'namespace', 'list']);
    kvId = findUuidNear(list, KV_TITLE);
  } catch (e) { warn(`kv list 失败: ${extractWranglerError(e.message).split('\n')[0]}`); }
  if (kvId) ok(`KV 已存在: ${KV_TITLE} (${kvId})`);
  else {
    try {
      const out = run('npx', ['wrangler', 'kv', 'namespace', 'create', KV_TITLE]);
      const m = out.match(/"id"\s*:\s*"([^"]+)"/) || out.match(/id\s*=\s*"([^"]+)"/);
      kvId = m ? m[1] : findUuidNear(out, KV_TITLE);
      if (!kvId) fail(`KV 创建成功但拿不到 ID:\n${out}`);
      ok(`KV 已创建: ${KV_TITLE} (${kvId})`);
    } catch (e) { fail(`KV 创建失败:\n${extractWranglerError(e.message)}`); }
  }

  try {
    const list = run('npx', ['wrangler', 'r2', 'bucket', 'list']);
    if (list.includes(R2_BUCKET)) ok(`R2 已存在: ${R2_BUCKET}`);
    else { run('npx', ['wrangler', 'r2', 'bucket', 'create', R2_BUCKET]); ok(`R2 已创建: ${R2_BUCKET}`); }
  } catch (e) {
    const msg = e.message || '';
    if (/10042|enable R2|dashboard/i.test(msg)) {
      fail('R2 未激活（错误 10042）。请先去 Cloudflare Dashboard → R2 里点一下激活（需绑卡，免费 10GB/月），\n然后重新运行本脚本。注意：这是唯一必须手动做的资源准备。');
    }
    fail(`R2 检查/创建失败:\n${extractWranglerError(msg)}`);
  }

  // 步骤 5: 生成 wrangler.toml
  step(5, '生成 wrangler.toml');
  // jwt_secret 复用旧值（重跑不更换，避免已登录用户全部掉线）；首次才随机生成
  let jwtSecret = '';
  const prevToml = join(WORKER_DIR, 'wrangler.toml');
  if (existsSync(prevToml)) {
    const mm = readFileSync(prevToml, 'utf8').match(/^jwt_secret\s*=\s*"([^"]+)"/m);
    if (mm) jwtSecret = mm[1];
  }
  if (!jwtSecret) {
    jwtSecret = randomBytes(24).toString('hex');
    warn('jwt_secret 已随机生成并写入配置，请勿泄露（它也是数据库初始化接口的钥匙）');
  } else {
    ok('沿用已有的 jwt_secret（已登录用户不受影响）');
  }
  const domainToml = domains.map((d) => `"${d}"`).join(', ');
  const toml =
`name = "${WORKER_NAME}"
main = "src/index.js"
compatibility_date = "2025-06-04"
keep_vars = true

[observability]
enabled = true

[[d1_databases]]
binding = "db"
database_name = "${D1_NAME}"
database_id = "${d1Id}"

[[kv_namespaces]]
binding = "kv"
id = "${kvId}"

[[r2_buckets]]
binding = "r2"
bucket_name = "${R2_BUCKET}"

# 可选：Cloudflare 原生发件（需在 Dashboard 启用 Email Sending 后取消注释）
#[[send_email]]
#name = "email"

[ai]
binding = "ai"

[assets]
binding = "assets"
directory = "./dist"
not_found_handling = "single-page-application"
run_worker_first = true

[triggers]
crons = ["0 * * * *"]

[vars]
#ai_model = ""
#analysis_cache = false
#orm_log = false
domain = [${domainToml}]
admin = "${adminEmail}"
jwt_secret = "${jwtSecret}"
`;
  writeFileSync(join(WORKER_DIR, 'wrangler.toml'), toml);
  ok('mail-worker/wrangler.toml 已生成（绑定与变量已回填）');

  // 步骤 6: 安装依赖
  step(6, '安装依赖（pnpm install，需几分钟）');
  runLive('pnpm', ['install'], { cwd: VUE_DIR });
  runLive('pnpm', ['install'], { cwd: WORKER_DIR });
  ok('依赖安装完成');

  // 步骤 7: 构建前端
  step(7, '构建前端（vite build --mode release）');
  runLive('pnpm', ['run', 'build'], { cwd: VUE_DIR });
  if (!existsSync(join(WORKER_DIR, 'dist', 'index.html'))) fail('前端构建失败：mail-worker/dist/index.html 不存在');
  ok('前端已构建到 mail-worker/dist');

  // 步骤 8: 部署
  step(8, `部署 Worker: ${WORKER_NAME}`);
  if (!(await confirm('开始 wrangler deploy？'))) fail('已取消');
  let deployOut = '';
  try {
    deployOut = run('npx', ['wrangler', 'deploy'], { cwd: WORKER_DIR });
    log(deployOut.split('\n').filter((l) => /workers\.dev|Uploaded|Published/i.test(l)).join('\n'));
  } catch (e) { fail(`部署失败:\n${extractWranglerError(e.message)}`); }
  const mUrl = deployOut.match(/https:\/\/[a-z0-9-]+\.[a-z0-9-]+\.workers\.dev/i);
  const siteUrl = mUrl ? mUrl[0] : '';
  if (siteUrl) ok(`部署成功: ${siteUrl}`);
  else warn('部署完成，但没解析到 workers.dev 地址，请去 Dashboard 查看');

  // 步骤 9: 初始化数据库（注意：hono 只挂在 /api/* 后面，所以是 /api/init/:secret）
  if (siteUrl) {
    step(9, '初始化数据库（/api/init/:secret）');
    const initUrl = `${siteUrl}/api/init/${jwtSecret}`;
    try {
      const text = await fetchText(initUrl);
      if (/success/i.test(text)) ok('数据库初始化成功');
      else fail(`初始化接口返回异常: ${text.slice(0, 200)}`);
    } catch (e) { fail(`初始化请求失败: ${e.message}\n可手动在浏览器打开 ${initUrl} 重试`); }
  }

  log('\n=== 部署完成 ===');
  if (siteUrl) log(`  网站地址: ${siteUrl}`);
  log(`  管理员邮箱: ${adminEmail}（去网站上注册该邮箱，自动成为管理员）`);
  log('\n  后续手动步骤（脚本做不了）：');
  log('  A. 发邮件：去 resend.com 申请 API Key，填到管理后台「设置」里');
  log('  B. 收邮件：域名 DNS 接入 Cloudflare 后，在 Email Routing 中把收件路由到本 Worker');
  log('     （Dashboard → 你的域名 → Email → Email Routing → 启用并添加路由规则指向 Worker）');
  log('  C. 发件 DNS：按 Resend 文档给域名配 SPF / DKIM / DMARC 记录，否则进垃圾箱');
}

main().catch((e) => fail(e.message || String(e)));
