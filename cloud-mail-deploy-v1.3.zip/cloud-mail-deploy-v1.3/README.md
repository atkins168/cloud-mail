# Cloud Mail 一键部署到 Cloudflare（v1.3）

项目：https://github.com/maillab/cloud-mail —— 基于 Cloudflare 的邮箱服务（发邮件/收邮件/附件/管理后台）。

双击 `deploy-cloud-mail.bat`（或 `node deploy-cloud-mail.mjs`），按提示输入**邮件域名**和**管理员邮箱**即可。脚本幂等，可反复运行。

## 目录结构

```
.
├── deploy-cloud-mail.mjs   一键部署脚本（Node 18+）
├── deploy-cloud-mail.bat   Windows 双击入口（纯 ASCII）
├── VERSION                 版本号
├── README.md               本文件
└── cloud-mail/             项目源码
    ├── mail-vue/           前端（Vue3，构建后输出到 mail-worker/dist）
    └── mail-worker/        后端（Hono Worker，API + 静态资源同体 served）
```

## 前置条件

1. Node.js 18+（https://nodejs.org，选 LTS）
2. `npx wrangler login` 登录过一次（浏览器授权）；或设置 `CLOUDFLARE_API_TOKEN`
3. **R2 必须先在 Dashboard 里激活**（需绑卡，免费 10GB/月），否则脚本会在 R2 步骤停下提示
4. 国内网络：`set HTTPS_PROXY=http://127.0.0.1:10808`

## 脚本会做的事

1. 检查 node / pnpm（没有自动装）/ wrangler 登录
2. 问你要用的**邮件域名**（多个用英文逗号分隔）和**管理员邮箱**（必须属于这些域名）
3. 自动创建（或复用）D1 `cloud-mail-db`、KV `cloud-mail-kv`、R2 `cloud-mail-r2`
4. 生成随机 `jwt_secret`，生成 `mail-worker/wrangler.toml` 并回填绑定 ID、域名、管理员
5. `pnpm install` + 构建前端到 `mail-worker/dist`
6. `wrangler deploy`（Worker 名默认 `cloud-mail`，API 与前端同源，`/api/*` 走后端）
7. 自动请求 `https://<worker>/init/<jwt_secret>` 初始化数据库（建表+迁移）

## 常用参数

```
node deploy-cloud-mail.mjs --yes --domain mail.example.com --admin-email admin@mail.example.com
node deploy-cloud-mail.mjs --worker-name my-mail --d1-name mydb --kv-name mykv --r2-name myr2
```

## 部署后手动步骤（脚本做不了）

- **A. 注册管理员**：打开网站，用管理员邮箱注册账号，自动成为管理员
- **B. 发邮件**：去 resend.com 申请 API Key，填到管理后台「设置」里（按域名配置）
- **C. 收邮件**：域名 DNS 接入 Cloudflare 后，Dashboard → 域名 → Email → Email Routing，启用并添加路由规则指向本 Worker（需 Catch-all 或按地址路由）
- **D. 发件 DNS**：按 Resend 文档给域名添加 SPF / DKIM / DMARC 记录，否则邮件进垃圾箱

## Resend 配置（发邮件用）

视频讲解：https://www.youtube.com/watch?v=3nzW1PUbkDs

### 1. 验证域名
1. 打开 https://resend.com/domains → Add Domain，填你的邮件域名（如 `xx.com`）
2. 按 Resend 给出的 DNS 记录，在 Cloudflare 里添加：
   - SPF：`v=spf1 include:amazonses.com ~all`（注意：一个域名只能有一条 SPF，如已有旧的直接覆盖合并）
   - DKIM：Resend 给的 `resend._domainkey` TXT 记录
3. 等状态变 Verified（通常几分钟）

### 2. 创建 API Key
https://resend.com/api-keys → Create API Key → 复制保存（只显示一次）

### 3. 填到 Cloud Mail 后台
用管理员账号登录 Cloud Mail → 管理后台「设置」→ 找到 Resend 配置（`resendTokens`），按域名填写：
`{"xx.com": "re_xxxxxxxxxxxx"}`（一个域名配一个 Key）

### 4. 配置 Webhook（回写发送状态）
Resend Dashboard → Webhooks → Add webhook：
- Endpoint URL：`https://<你的域名>/api/webhooks`
- Events 只勾这 5 个（代码里实际处理的）：
  `email.delivered` / `email.bounced` / `email.failed` / `email.delivery_delayed` / `email.complained`
- 作用：Resend 把"已送达/退信/失败/延迟/被投诉"推回来，Cloud Mail 更新邮件状态

配完后发一封测试邮件，在 Cloud Mail 的发送记录里能看到状态从"已发送"变成"已送达"即成功。

## 技术要点（给好奇的你）

- 前后端同体：单个 Worker 同时提供 `/api/*`（Hono）和前端静态资源（`[assets]` + `run_worker_first`）
- 收件：Worker 的 `email()` handler 解析 MIME（postal-mime），附件存 R2
- 发件：优先 Resend（按域名配 key），可选 Cloudflare 原生 `send_email` binding
- 定时任务：cron 每小时跑（清理、重置日发送量、收件补全）
- 验证码识别：Workers AI（`[ai]` binding，无需额外配置）

## 常见问题

- **R2 10042 报错**：去 Dashboard → R2 点一下激活后再重跑
- **pnpm 装不上**：手动 `npm install -g pnpm` 后重跑
- **数据库没初始化**：浏览器打开 `https://<你的worker>/api/init/<jwt_secret>` 手动触发（jwt_secret 在生成的 wrangler.toml 里）
- **换域名/加域名**：改 `mail-worker/wrangler.toml` 的 `domain` 后重跑脚本（会重新部署）
