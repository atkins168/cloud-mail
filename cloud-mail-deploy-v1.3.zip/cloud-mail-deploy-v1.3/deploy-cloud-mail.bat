@echo off
rem Cloud Mail one-click deploy launcher (ASCII only).
rem All user-facing messages are printed by deploy-cloud-mail.mjs.
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js not found. Install Node.js LTS 18+ first, then rerun.
  pause
  exit /b 1
)
node deploy-cloud-mail.mjs %*
pause
